from gapp import mcmcdgp
import numpy as np
from numpy import loadtxt, random, savetxt, zeros


if __name__=="__main__":
    (X, Y, Sigma) = loadtxt("../inputdata.txt", unpack='True')
    (DX, DY, DSigma) = loadtxt("../dinputdata.txt", unpack='True')

    xmin = 0.0
    xmax = 10.0
    nstar = 50

    nwalker = 50
    theta0 = random.normal(2.0, 0.2, (nwalker, 2))

    g = mcmcdgp.MCMCDGaussianProcess(X, Y, Sigma, theta0, Niter=50,
                                     dX=DX, dY=DY, dSigma=DSigma,
                                     cXstar=(xmin, xmax, nstar),
                                     reclist=[0, 1, 2, 3],threads=8)



    (Xstar, rec, drec, ddrec, dddrec) = g.mcmcdgp()


    savetxt("rec.txt", rec)
    savetxt("drec.txt", drec)
    savetxt("ddrec.txt", drec)
    savetxt("dddrec.txt", drec)
    savetxt("Xstar.txt", Xstar)

    pred = zeros((nstar,3))
    pred[:, 0] = Xstar[:, 0]
    pred[:, 1] = np.mean(rec, axis=1)
    pred[:, 2] = np.std(rec, axis=1)

    savetxt("f.txt", pred)


    dpred = zeros((nstar,3))
    dpred[:, 0] = Xstar[:, 0]
    dpred[:, 1] = np.mean(drec, axis=1)
    dpred[:, 2] = np.std(drec, axis=1)

    savetxt("df.txt", dpred)

    ddpred = zeros((nstar,3))
    ddpred[:, 0] = Xstar[:, 0]
    ddpred[:, 1] = np.mean(ddrec, axis=1)
    ddpred[:, 2] = np.std(ddrec, axis=1)

    savetxt("ddf.txt", ddpred)
    
    dddpred = zeros((nstar,3))
    dddpred[:, 0] = Xstar[:, 0]
    dddpred[:, 1] = np.mean(dddrec, axis=1)
    dddpred[:, 2] = np.std(dddrec, axis=1)

    savetxt("dddf.txt", dddpred)
    # test if matplotlib is installed
    try:
        import matplotlib.pyplot
    except:
        print("matplotlib not installed. no plots will be produced.")
        exit
    # create plot
    #import plot
    #plot.plot(X, Y, Sigma, DX, DY, DSigma, pred, dpred)
    import plotddd
    plotddd.plot(X, Y, Sigma, DX, DY, DSigma, pred, dpred, ddpred, dddpred)

