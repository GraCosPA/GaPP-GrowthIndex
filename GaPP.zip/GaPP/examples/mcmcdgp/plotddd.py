import matplotlib.pyplot as plt
from numpy import loadtxt

def plot(X, Y, Sigma, dX, dY, dSigma, rec, drec, ddrec, dddrec):

    plt.subplot(221)
    plt.xlim(0, 10)
    plt.fill_between(rec[:, 0], rec[:, 1] + rec[:, 2], rec[:, 1] - rec[:, 2],
                     facecolor='lightblue')
    plt.plot(rec[:, 0], rec[:, 1])
    plt.errorbar(X, Y, Sigma, color='red', fmt='_')
    plt.xlabel('x')
    plt.ylabel('f(x)')

    plt.subplot(222)
    plt.xlim(0, 10)
    plt.fill_between(drec[:, 0], drec[:, 1] + drec[:, 2], 
                     drec[:, 1] - drec[:, 2], facecolor='lightblue')
    plt.plot(drec[:, 0], drec[:, 1])
    plt.errorbar(dX, dY, dSigma, color='red', fmt='_')
    plt.xlabel('x')
    plt.ylabel("f'(x)")
    
    plt.subplot(223)
    plt.xlim(0, 10)
    plt.fill_between(ddrec[:, 0], ddrec[:, 1] + ddrec[:, 2],
                     ddrec[:, 1] - ddrec[:, 2], facecolor='lightblue')
    plt.plot(ddrec[:, 0], ddrec[:, 1])
    #plt.errorbar(dX, dY, dSigma, color='red', fmt='_')
    plt.xlabel('x')
    plt.ylabel("f'''(x)")
    
    plt.subplot(224)
    plt.xlim(0, 10)
    plt.fill_between(dddrec[:, 0], dddrec[:, 1] + dddrec[:, 2],
                     dddrec[:, 1] - dddrec[:, 2], facecolor='lightblue')
    plt.plot(dddrec[:, 0], dddrec[:, 1])
    #plt.errorbar(dX, dY, dSigma, color='red', fmt='_')
    plt.xlabel('x')
    plt.ylabel("r$f^{(4)}(x)$")

    plt.savefig('plotddd.pdf')


if __name__=="__main__":
    (X, Y, Sigma) = loadtxt("../inputdata.txt", unpack='True')
    (dX, dY, dSigma) = loadtxt("../dinputdata.txt", unpack='True')
    rec = loadtxt("f.txt")
    drec = loadtxt("df.txt")
    ddrec = loadtxt("ddf.txt")
    dddrec = loadtxt("dddf.txt")
        
    plot(X, Y, Sigma, dX, dY, dSigma, rec, drec, ddrec, dddrec)
