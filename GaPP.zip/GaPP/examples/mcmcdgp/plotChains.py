import matplotlib.pyplot as plt
import os
import corner
import emcee
from emcee.autocorr import AutocorrError
import numpy as np
from numpy import loadtxt
from getdist import plots, MCSamples

def plot(X, Y, Sigma, dX, dY, dSigma, rec, drec):

    plt.subplot(211)
    plt.xlim(0, 10)
    plt.fill_between(rec[:, 0], rec[:, 1] + rec[:, 2], rec[:, 1] - rec[:, 2],
                     facecolor='lightblue')
    plt.plot(rec[:, 0], rec[:, 1])
    plt.errorbar(X, Y, Sigma, color='red', fmt='_')
    plt.xlabel('x')
    plt.ylabel('f(x)')

    plt.subplot(212)
    plt.xlim(0, 10)
    plt.fill_between(drec[:, 0], drec[:, 1] + drec[:, 2], 
                     drec[:, 1] - drec[:, 2], facecolor='lightblue')
    plt.plot(drec[:, 0], drec[:, 1])
    plt.errorbar(dX, dY, dSigma, color='red', fmt='_')
    plt.xlabel('x')
    plt.ylabel("f'(x)")

    plt.savefig('plot.pdf')


if __name__=="__main__":
    #(X, Y, Sigma) = loadtxt("../inputdata.txt", unpack='True')
    #(dX, dY, dSigma) = loadtxt("../dinputdata.txt", unpack='True')
    #rec = loadtxt("f.txt")
    #drec = loadtxt("df.txt")

    #plot(X, Y, Sigma, dX, dY, dSigma, rec, drec)
    
    directory = './'
    for filename in os.listdir(directory):
        if filename.endswith(".h5"):
            path = os.path.join(directory, filename)
            
            reader = emcee.backends.HDFBackend(path, read_only=True)
            
############################################################
    # SUMMARY PLOTS

            print('Plotting chains... ')
            ndim = 2
            fig, axes = plt.subplots(ndim, figsize=(10, 7), sharex=True)
            samples = reader.get_chain()
            print("all chains shape : {0}".format(samples.shape))
            #labels = allPops.get_labels(config.params_inference)
            for i in range(ndim):
                ax = axes[i]
                ax.plot(samples[:, :, i], "k", alpha=0.3)
                ax.set_xlim(0, len(samples))
                #ax.set_ylabel(labels[i])
                ax.yaxis.set_label_coords(-0.1, 0.5)

            axes[-1].set_xlabel("step number");
    
            plt.savefig(os.path.join(directory,'chains.pdf'))
            plt.close()
    
            try:
                tau = reader.get_autocorr_time(quiet=True)
                print('auto correlation time = %s' % tau)
            except AutocorrError as e:
                # this is the case the chain is shorter than 50*(autocorr time)
                print('%s' % e)
                # tau = [410., 100., 140, 140]
                tau = e.tau
                print('setting correlation time to the current estimate.')
            if np.any(np.isnan(tau)):
               burnin=0
               thin=1
            else:
               # works only for long chains
               # use auto-correlation time to estimate burnin here
               burnin = int(2 * np.max(tau))
               thin = int(0.5 * np.min(tau))
            samples = reader.get_chain(discard=burnin, flat=True, thin=thin)
            print("burn-in: {0}".format(burnin))
            print("thin: {0}".format(thin))
            print("flat chains shape (after discarding burnin phase and thin): {0}".format(samples.shape))
    
    ############################################################
    # END
            try:
                all_samples = np.append(all_samples, samples, axis=0)
            except:
                all_samples = samples
        else:
            continue

    # compute mean
    dim_of_param = len(samples[0])
    mean = np.mean(samples, axis=0)
    print('mean = %s' % mean)

    #if 'mock' in config.dataset_names:
    print('Plotting cornerplot... ')
    trueValues=None
    figure = corner.corner(samples,
                           #labels=labels,
                           #truths=trueValues,
                           quantiles=[0.16, 0.5, 0.84],
                           show_titles=True,
                           title_kwargs={"fontsize": 12})
    axes = np.array(figure.axes).reshape((dim_of_param, dim_of_param))

    plt.savefig(os.path.join(directory,'corner.pdf'))
    plt.close()
    # GetDist - begin
    labels = ["$\sigma_f$","$\ell$"]
    names = labels
    GitDistsamples = MCSamples(samples=samples, names = names)
    print(GitDistsamples.getNumSampleSummaryText())
    GitDistsamples.contours = np.array([0.67, 0.95, 0.99])
    GitDistsamples.updateBaseStatistics()
    # Plot
    g = plots.get_subplot_plotter(width_inch=6.0)
    g.settings.axes_fontsize = 7.0
    g.settings.figure_legend_frame = False
    g.settings.solid_contour_palefactor = 0.9
    g.settings.alpha_filled_add = 0.6
    g.settings.num_plot_contours = 3
    #g.triangle_plot([GitDistsamples], filled=True, contour_colors=cm.tab10, legend_labels=['GW'])
    g.triangle_plot([GitDistsamples], filled=True, contour_colors=["red"], legend_labels=['Parameters'])
    #upper_kwargs = {'contour_colors': cm.tab10.colors[4:], 'contour_ls': ['-', '--'],'filled': [True, False], 'show_1d': [True, True], 'contour_lws':[1,2]}
    #g.triangle_plot([samples,new_samples], ['x0', 'x1', 'x2'], filled=True,contour_colors=['C3','green'], markers={'x0':-0.5},upper_roots = [samples2, cut_samples],upper_kwargs = upper_kwargs,upper_label_right=True,legend_labels=['Samples','Reweighted','Second', 'Cut']);
    #g.plots_1d([samples1, samples2], ['x0', 'x1', 'x2'], nx=3, share_y=True, legend_ncol =2,markers={'x1':0}, colors=['red', 'green'], ls=['--', '-.'])
    #g.plots_2d([samples1, samples2], param_pairs=[['x0', 'x1'], ['x1', 'x2']],nx=2, legend_ncol=2, colors=['blue', 'red'])
    #g.rectangle_plot(['x0','x1'], ['x2','x3'], roots = [samples1, samples2], filled=True)
    #g.triangle_plot([samples1, samples2], ['x0','x1','x2'], plot_3d_with_param='x3')
    g.export(os.path.join(directory,'corner.eps'))
    # export the results
    print('--- The Model Prameters Table With Errors ---')
    print(GitDistsamples.getTable().tableTex())
    print('--- The Model Prameters Covariance Matrix ---')
    print(GitDistsamples.getCov())
    print('--- The Model Prameters Correlation Matrix ---')
    print(GitDistsamples.getCorrelationMatrix())
    print('---  Marginalized 1D Parameter Constraints ---')
    print(GitDistsamples.getMargeStats(include_bestfit=False))
    #for s in labels:
    #    print(GitDistsamples.getInlineLatex(s,limit=2))
    #print('---  PCA Analysis ---')
    #print(GitDistsamples.PCA(labels))
    # GetDist - end


    accF_fname = os.path.join(directory, 'acceptance_fraction.txt')
    accF = np.loadtxt(accF_fname)
    index = len(accF)
                   
    acc_fname = os.path.join(directory, 'autocorr.txt')
    autocorr = np.loadtxt(acc_fname)
    
    convergence_ntaus = 50
    if index>2:
        print('Plotting autocorrelation... ')
        n = 100 * np.arange(1, index + 1)
        y = autocorr[:index]
        plt.plot(n, n / convergence_ntaus, "--k", label='N/%s'%convergence_ntaus )
        plt.plot(n, y)
        plt.xlim(n.min(), n.max())
        plt.ylim(0, y.max() + 0.1 * (y.max() - y.min()))
        plt.xlabel("number of steps")
        plt.ylabel(r"mean $\hat{\tau}$");
        plt.legend();
        plt.savefig(os.path.join(directory,'autocorr.pdf'))
        
    ############################################################
